import Logo from './../assets/logos/LearnZaniaLogo.png'
import HomeBanner from './../assets/home_banner.png'
import Education from './../assets/education.png'
import Message from './../assets/message.png'
import Free from './../assets/free-education.png'
import Working from './../assets/computer.png'
import Woman from './../assets/woman.png'
import home from './../assets/home.png'
import doubt from './../assets/doubt.png'
import doubtassistant from './../assets/doubtassistant.gif'
import videolec1 from './../assets/videolec1.jpg'
import videolec2 from './../assets/videolec2.jpg'
import Quiz from './../assets/Quiz.png'
import blog from './../assets/blog.png'
import video from './../assets/video.png'
import more from './../assets/more.png'
import Frontpg from './../assets/Frontpg.png'
import Student from './../assets/Student.png'
import Teacher from './../assets/Teacher.png'
import confuse from "./../assets/confuse.png";
import FeatureStudentImage1 from "./../assets/feature_student_page_img1.png";
import FeatureStudentImage2 from "./../assets/feature_student_page_img2.png";
import FeatureStudentImage3 from "./../assets/feature_student_page_img3.png";
import FeatureStudentImage4 from "./../assets/feature_student_page_img4.png";
import FeatureStudentImage5 from "./../assets/feature_student_page_img5.png";
import FeatureTeacherImage1 from "./../assets/feature_teacher_page_img1.png";
import FeatureTeacherImage2 from "./../assets/feature_teacher_page_img2.png";
import FeatureTeacherImage3 from "./../assets/feature_teacher_page_img3.png";
import ws1 from "./../assets/ws1.png";
import ws2 from "./../assets/ws2.png";
import ws3 from "./../assets/ws3.png";
import ws4 from "./../assets/ws4.jpg";
import ws5 from "./../assets/ws5.png";
import ws6 from "./../assets/ws6.png";
import wt1 from "./../assets/wt1.png";
import wt2 from "./../assets/wt2.png";
import wt3 from "./../assets/wt3.png";
import wt4 from "./../assets/wt4.png";
import wt5 from "./../assets/wt5.jpg";
import wt6 from "./../assets/wt6.png";
import Aboutedu1 from "./../assets/Aboutedu1.png";
import Aboutedu2 from "./../assets/Aboutedu2.png";
import teacher1 from "./../assets/teacher1.jpg";
import teacher2 from "./../assets/teacher2.png";
import studentjoin from "./../assets/studentjoin.jpg";
import teacherjoin from "./../assets/teacherjoin.jpg";
import Whyedu1 from "./../assets/Whyedu1.png";
import Whyedu2 from "./../assets/Whyedu2.png";
import pro from "./../assets/pro.jpg";
export default {

    Logo,
    homeBanner:HomeBanner,
    Education,
    Message,
    Free,
    Working,
    Woman,
    home,
    doubt,
    doubtassistant,
    videolec1,
    videolec2,
    Quiz,
    blog,
    video,
    more,
    Frontpg,
    Student,
    Teacher,
    confuse,
    FeatureStudentImage1,
    FeatureStudentImage2,
    FeatureStudentImage3,
    FeatureStudentImage4,
    FeatureStudentImage5,
    FeatureTeacherImage1,
    FeatureTeacherImage2,
    FeatureTeacherImage3,
    ws1,
    ws2,
    ws3,
    ws4,
    ws5,
    ws6,
    wt1,
    wt2,
    wt3,
    wt4,
    wt5,
    wt6,
    Aboutedu1,
    Aboutedu2,
    studentjoin,
    teacherjoin,
    teacher1,
    teacher2,
    Whyedu1,
    Whyedu2,
    pro
}

