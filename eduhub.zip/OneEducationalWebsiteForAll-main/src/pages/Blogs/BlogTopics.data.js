const TopicsData = [
    { 
        cardimg: 'https://www.stratospherenetworks.com/blog/wp-content/uploads/2020/08/virtual-learning-stock-photo.jpg',
        title: 'Virtual Learning'
    },
    { 
        cardimg: 'https://images.pexels.com/photos/34600/pexels-photo.jpg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
        title: 'Programming'
    },
    { 
        cardimg: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
        title: 'Software Development'
    },
    { 
        cardimg: 'https://www.livecareer.com/wp-content/uploads/2020/06/best-remote-jobs-hero-866x577.jpg',
        title: 'Get Remote Jobs'
    },
    { 
        cardimg: 'https://entrepreneurhandbook.co.uk/wp-content/uploads/2020/08/Web-development-2.0.jpg.webp',
        title: 'Web Development'
    },
    { 
        cardimg: 'https://cdn.shortpixel.ai/client/q_glossy,ret_img,w_2560,h_1536/https://netinteractive.co/wp-content/uploads/2021/05/Blue-and-Red-60x36-Landscape-Voters-Education-Banner-4.png',
        title: 'Best Resources for Coding'
    },
    { 
        cardimg: 'https://www.livecareer.com/wp-content/uploads/2020/06/best-remote-jobs-hero-866x577.jpg',
        title: 'Get Remote Jobs'
    },
    { 
        cardimg: 'https://entrepreneurhandbook.co.uk/wp-content/uploads/2020/08/Web-development-2.0.jpg.webp',
        title: 'Web Development'
    },
    { 
        cardimg: 'https://cdn.shortpixel.ai/client/q_glossy,ret_img,w_2560,h_1536/https://netinteractive.co/wp-content/uploads/2021/05/Blue-and-Red-60x36-Landscape-Voters-Education-Banner-4.png',
        title: 'Best Resources for Coding'
    },
    { 
        cardimg: 'https://www.stratospherenetworks.com/blog/wp-content/uploads/2020/08/virtual-learning-stock-photo.jpg',
        title: 'Virtual Learning'
    },
    { 
        cardimg: 'https://images.pexels.com/photos/34600/pexels-photo.jpg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
        title: 'Programming'
    },
    { 
        cardimg: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
        title: 'Software Development'
    },
    { 
        cardimg: 'https://www.stratospherenetworks.com/blog/wp-content/uploads/2020/08/virtual-learning-stock-photo.jpg',
        title: 'Virtual Learning'
    },
    { 
        cardimg: 'https://images.pexels.com/photos/34600/pexels-photo.jpg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
        title: 'Programming'
    },
    { 
        cardimg: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
        title: 'Software Development'
    },
    { 
        cardimg: 'https://cdn.shortpixel.ai/client/q_glossy,ret_img,w_2560,h_1536/https://netinteractive.co/wp-content/uploads/2021/05/Blue-and-Red-60x36-Landscape-Voters-Education-Banner-4.png',
        title: 'Best Resources for Coding'
    },
    { 
        cardimg: 'https://entrepreneurhandbook.co.uk/wp-content/uploads/2020/08/Web-development-2.0.jpg.webp',
        title: 'Web Development'
    },
    { 
        cardimg: 'https://cdn.shortpixel.ai/client/q_glossy,ret_img,w_2560,h_1536/https://netinteractive.co/wp-content/uploads/2021/05/Blue-and-Red-60x36-Landscape-Voters-Education-Banner-4.png',
        title: 'Best Resources for Coding'
    }
];

export default TopicsData;